//  Puja Pattel
//  ITP 165, Fall 2015
//  Lab 20
//  pujadpat@usc.edu

#include "AddressBook.h"

int main()
{
    std::string first ("Puja");
    std::string last ("Patel");
    std::string phone ("123-456-7890");
    
    AddressBook testBook(20);
    testBook.addContact(first, last, phone);
    
    first = "Doggy";
    last = "Ears";
    phone = "000-000-0000";
    
    testBook.addContact(first, last, phone);
    
    testBook.print();
    
    return 0;
}
